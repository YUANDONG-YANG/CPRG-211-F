using System;
using oop.Models.Abstract;

namespace oop.Models
{
    public class PartTime(string id, string name, long sin, double hourlyRate, double hoursWorked) : Employee(id, name, sin)
    {
        public double HourlyRate { get; set; } = hourlyRate;
        public double HoursWorked { get; set; } = hoursWorked;

        // 兼职：没有加班费
        public override double CalculateWeeklyPay()
        {
            return HourlyRate * HoursWorked;
        }

        public override string ToString()
        {
            return base.ToString() + $", HourlyRate={HourlyRate}, HoursWorked={HoursWorked}";
        }
    }
}