using System;
using oop.Models.Abstract;

namespace oop.Models
{
    public class Wages(string id, string name, long sin, double hourlyRate, double hoursWorked) : Employee(id, name, sin)
    {
        public double HourlyRate { get; set; } = hourlyRate;
        public double HoursWorked { get; set; } = hoursWorked;

        // Salary = rate * hours, hours exceeding 40 will be charged at 1.5 times the rate
        public override double CalculateWeeklyPay()
        {
            const double OVERTIME_THRESHOLD = 40.0;
            const double OVERTIME_MULTIPLIER = 1.5;

            if (HoursWorked <= OVERTIME_THRESHOLD)
            {
                return HourlyRate * HoursWorked;
            }
            else
            {
                double overtimeHours = HoursWorked - OVERTIME_THRESHOLD;
                double overtimePay = overtimeHours * HourlyRate * OVERTIME_MULTIPLIER;
                double regularPay = OVERTIME_THRESHOLD * HourlyRate;
                return regularPay + overtimePay;
            }
        }

        public override string ToString()
        {
            return base.ToString() + $", HourlyRate={HourlyRate}, HoursWorked={HoursWorked}";
        }
    }




}